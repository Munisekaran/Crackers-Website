<?php
    include 'includes/common.php';
?>
<!DOCTYPE html>
<html>
    <head>
        <title>
            About Us | Crackers Store
        </title>
        <!-- link to Bootstrap minified css-->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
		<!-- link to Jquery minified-->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
		<!-- link to Bootstrap JS -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="crackerstore.css">
    </head>
    <body>
        <?php
            include 'includes/header.php';
        ?>
        <div class="container" style="padding-bottom:220px">
        <div style="padding-top:150px" class="col-xs-6">
        <div class="main-page-wrapper">
		
        <div class="page-title  page-title-default title-size-small title-design-default color-scheme-light" style="">
    <div class="container">
                                                                    <h1 class="entry-title title">
                    About Us								</h1>

                                            
                                            <div class="breadcrumbs"><a href="https://www.crackersindia.com/" rel="v:url" property="v:title">Home</a> » <span class="current">About Us</span></div><!-- .breadcrumbs -->																		</div>
</div>

<!-- MAIN CONTENT AREA -->
<div class="container">
<div class="row content-layout-wrapper align-items-start">
        <div data-elementor-type="wp-page" data-elementor-id="12325" class="elementor elementor-12325">
                    <section class="wd-negative-gap elementor-section elementor-top-section elementor-element elementor-element-f2cdce7 elementor-section-content-middle elementor-section-boxed elementor-section-height-default elementor-section-height-default wd-section-disabled" data-id="f2cdce7" data-element_type="section">
        <div class="elementor-container elementor-column-gap-wide">
    <div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-70639750" data-id="70639750" data-element_type="column">
<div class="elementor-widget-wrap elementor-element-populated">
                <div class="elementor-element elementor-element-68c660d5 elementor-widget elementor-widget-image" data-id="68c660d5" data-element_type="widget" data-widget_type="image.default">
<div class="elementor-widget-container">
<style>/*! elementor - v3.18.0 - 08-12-2023 */
.elementor-widget-image{text-align:center}.elementor-widget-image a{display:inline-block}.elementor-widget-image a img[src$=".svg"]{width:48px}.elementor-widget-image img{vertical-align:middle;display:inline-block}</style>												<img fetchpriority="high" decoding="async" width="725" height="439" src="https://www.crackersindia.com/wp-content/webp-express/webp-images/uploads/2019/01/diwali-firecrackers-with-kids1.jpg.webp" class="attachment-full size-full wp-image-12302" alt="" srcset="https://www.crackersindia.com/wp-content/webp-express/webp-images/uploads/2019/01/diwali-firecrackers-with-kids1.jpg.webp 725w,  https://www.crackersindia.com/wp-content/webp-express/webp-images/uploads/2019/01/diwali-firecrackers-with-kids1-150x91.jpg.webp 150w,  https://www.crackersindia.com/wp-content/webp-express/webp-images/uploads/2019/01/diwali-firecrackers-with-kids1-500x303.jpg.webp 500w,  https://www.crackersindia.com/wp-content/webp-express/webp-images/uploads/2019/01/diwali-firecrackers-with-kids1-300x182.jpg.webp 300w" sizes="(max-width: 725px) 100vw, 725px">															</div>
</div>
    </div>
</div>
<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-414e2351" data-id="414e2351" data-element_type="column">
<div class="elementor-widget-wrap elementor-element-populated">
                <div class="elementor-element elementor-element-2514b773 elementor-widget elementor-widget-wd_title" data-id="2514b773" data-element_type="widget" data-widget_type="wd_title.default">
<div class="elementor-widget-container">
    <div class="title-wrapper set-mb-s reset-last-child wd-title-color-default wd-title-style-default wd-title-size-default text-left">


<div class="liner-continer">
<h4 class="woodmart-title-container title wd-fontsize-l">About Crackersindia.com</h4> 
            </div>

            <div class="title-after_title set-cont-mb-s reset-last-child wd-fontsize-xs">
    <p>Crackersindia.com is a leading crackers online shopping website and fireworks manufacturing company in Sivakasi, India. We provide the best crackers online in India at unbelievable prices.</p><p>Crackersindia.com sells original sivakasi fireworks &amp; fancy crackers. Buy Crackers online in India if you are from or around Bangalore, Chennai, Hyderabad, Coimbatore, Salem and we distribute all over Tamilnadu.</p><p>We are one of the leading crackers &amp; fireworks manufacturers in India successfully functioning from 1981. We do both wholesale and retail business. Our main motive is to give the best products to our customers. We also focus in manufacturing highly safety crackers. We have <strong>42 years</strong>&nbsp;<strong>of experience</strong>&nbsp;in the field of crackers and our main manufacturing industry is in&nbsp;<strong>Sivakasi.</strong></p><p>In our ongoing pursuit of excellence, we are pleased to introduce '<b>Senya Agencies</b>' as a legal and registered company, seamlessly integrated into our operations. This strategic addition further enhances our commitment to quality and adherence to regulatory standards, solidifying our position as a trusted name in the realm of crackers and fireworks.</p><p>Thank you for being a part of our journey.</p>				</div>
    </div>
</div>
</div>
    </div>
</div>
            </div>
</section>
<section class="wd-negative-gap elementor-section elementor-top-section elementor-element elementor-element-31e11144 elementor-section-boxed elementor-section-height-default elementor-section-height-default wd-section-disabled" data-id="31e11144" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
        <div class="elementor-container elementor-column-gap-default">
    <div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-1ddf5dd6" data-id="1ddf5dd6" data-element_type="column">
<div class="elementor-widget-wrap">
                    </div>
</div>
<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-4627e144" data-id="4627e144" data-element_type="column">
<div class="elementor-widget-wrap elementor-element-populated">
                <div class="elementor-element elementor-element-28615f9 elementor-widget elementor-widget-wd_title" data-id="28615f9" data-element_type="widget" data-widget_type="wd_title.default">
<div class="elementor-widget-container">
    <div class="title-wrapper set-mb-s reset-last-child wd-title-color-primary wd-title-style-default wd-title-size-default text-center">

            <div class="title-subtitle subtitle-color-primary subtitle-style-default wd-fontsize-xs">
    CRACKERS INDIA				</div>

<div class="liner-continer">
<h4 class="woodmart-title-container title wd-fontsize-l">Client Says About Us</h4> 
            </div>

    </div>
</div>
</div>
<div class="elementor-element elementor-element-d8de962 elementor-widget elementor-widget-wd_testimonials" data-id="d8de962" data-element_type="widget" data-widget_type="wd_testimonials.default">
<div class="elementor-widget-container">
    <div class="testimonials testimonials-wrapper testimonials-slider testimon-style-standard wd-fontsize-m color-scheme-light testimon-align-center wd-carousel-container wd-carousel-spacing-30" id="carousel-8741" data-owl-carousel="" data-speed="3000" data-slides_per_view_tablet="{&quot;size&quot;:&quot;&quot;}" data-slides_per_view_mobile="{&quot;size&quot;:&quot;&quot;}" data-wrap="yes" data-autoplay="yes" data-hide_prev_next_buttons="yes" data-scroll_per_page="" data-desktop="1" data-tablet="1" data-tablet_landscape="1" data-mobile="1">
<div class="owl-carousel wd-owl owl-items-lg-1 owl-items-md-1 owl-items-sm-1 owl-items-xs-1 owl-loaded owl-drag">
                    
                    
                    
                    
                    
                    
            <div class="owl-stage-outer"><div class="owl-stage" style="transform: translate3d(-2864px, 0px, 0px); transition: all 0.25s ease 0s; width: 9548px;"><div class="owl-item cloned" style="width: 954.8px;"><div class="testimonial column">
<div class="testimonial-inner">
    <div class="testimonial-avatar">
<img decoding="async" src="https://www.crackersindia.com/wp-content/webp-express/webp-images/uploads/2019/01/31.jpg.webp" class="testimonial-avatar-image">			</div>

<div class="testimonial-content">
<div class="testimonial-rating">
<span class="star-rating">
    <span style="width:100%"></span>
</span>
</div>

<p>I have been order past 4 years.. This site is awesome. You guys are really doing a great job delivering in cities on diwali season</p>
<footer>
RAM
                    <span>
        Bangalore					</span>
            </footer>
</div>
</div>
</div></div><div class="owl-item cloned" style="width: 954.8px;"><div class="testimonial column">
<div class="testimonial-inner">
    <div class="testimonial-avatar">
<img decoding="async" src="https://www.crackersindia.com/wp-content/webp-express/webp-images/uploads/2019/01/31.jpg.webp" class="testimonial-avatar-image">			</div>

<div class="testimonial-content">
<div class="testimonial-rating">
<span class="star-rating">
    <span style="width:100%"></span>
</span>
</div>

<p>I have ordered crackers for my Kids. They were enjoyed like anything. All crackers are very good on quality and safety wise.</p>
<footer>
VENKATESH
                    <span>
        Coimbatore					</span>
            </footer>
</div>
</div>
</div></div><div class="owl-item" style="width: 954.8px;"><div class="testimonial column">
<div class="testimonial-inner">
    <div class="testimonial-avatar">
<img decoding="async" src="https://www.crackersindia.com/wp-content/webp-express/webp-images/uploads/2019/01/31.jpg.webp" class="testimonial-avatar-image">			</div>

<div class="testimonial-content">
<div class="testimonial-rating">
<span class="star-rating">
    <span style="width:100%"></span>
</span>
</div>

<p>Service very excellent with in one week reach at home I m happy with that , quality was good . Every year I will buy crackers India only.</p>
<footer>
DIVYA
                    <span>
        Chennai					</span>
            </footer>
</div>
</div>
</div></div><div class="owl-item active" style="width: 954.8px;"><div class="testimonial column">
<div class="testimonial-inner">
    <div class="testimonial-avatar">
<img decoding="async" src="https://www.crackersindia.com/wp-content/webp-express/webp-images/uploads/2023/02/unnamed.png.webp" class="testimonial-avatar-image">			</div>

<div class="testimonial-content">
<div class="testimonial-rating">
<span class="star-rating">
    <span style="width:100%"></span>
</span>
</div>

<p>I have ordered Crackers for marriage function and received it on time. My family really enjoyed your varities. Thanks to Crackers India for valuable services.</p>
<footer>
JULIUS CEASER
                    <span>
        Nagerkovil					</span>
            </footer>
</div>
</div>
</div></div><div class="owl-item" style="width: 954.8px;"><div class="testimonial column">
<div class="testimonial-inner">
    <div class="testimonial-avatar">
<img decoding="async" src="https://www.crackersindia.com/wp-content/webp-express/webp-images/uploads/2019/01/11.jpg.webp" class="testimonial-avatar-image">			</div>

<div class="testimonial-content">
<div class="testimonial-rating">
<span class="star-rating">
    <span style="width:100%"></span>
</span>
</div>

<p>Excellent services. I will order Afternoon. Next Day Morning Delivery . Crackers also nice</p>
<footer>
AMIRTHARAJ
                    <span>
        Theni					</span>
            </footer>
</div>
</div>
</div></div><div class="owl-item" style="width: 954.8px;"><div class="testimonial column">
<div class="testimonial-inner">
    <div class="testimonial-avatar">
<img decoding="async" src="https://www.crackersindia.com/wp-content/webp-express/webp-images/uploads/2019/01/41.jpg.webp" class="testimonial-avatar-image">			</div>

<div class="testimonial-content">
<div class="testimonial-rating">
<span class="star-rating">
    <span style="width:100%"></span>
</span>
</div>

<p>I received my parcel, Thanks lot.. I checked received item's(qty) All the thinks i received without missing. And few crackers I tested the quality it's too good.</p>
<footer>
ANAND
                    <span>
        Chennai					</span>
            </footer>
</div>
</div>
</div></div><div class="owl-item" style="width: 954.8px;"><div class="testimonial column">
<div class="testimonial-inner">
    <div class="testimonial-avatar">
<img decoding="async" src="https://www.crackersindia.com/wp-content/webp-express/webp-images/uploads/2019/01/31.jpg.webp" class="testimonial-avatar-image">			</div>

<div class="testimonial-content">
<div class="testimonial-rating">
<span class="star-rating">
    <span style="width:100%"></span>
</span>
</div>

<p>I have been order past 4 years.. This site is awesome. You guys are really doing a great job delivering in cities on diwali season</p>
<footer>
RAM
                    <span>
        Bangalore					</span>
            </footer>
</div>
</div>
</div></div><div class="owl-item" style="width: 954.8px;"><div class="testimonial column">
<div class="testimonial-inner">
    <div class="testimonial-avatar">
<img decoding="async" src="https://www.crackersindia.com/wp-content/webp-express/webp-images/uploads/2019/01/31.jpg.webp" class="testimonial-avatar-image">			</div>

<div class="testimonial-content">
<div class="testimonial-rating">
<span class="star-rating">
    <span style="width:100%"></span>
</span>
</div>

<p>I have ordered crackers for my Kids. They were enjoyed like anything. All crackers are very good on quality and safety wise.</p>
<footer>
VENKATESH
                    <span>
        Coimbatore					</span>
            </footer>
</div>
</div>
</div></div><div class="owl-item cloned" style="width: 954.8px;"><div class="testimonial column">
<div class="testimonial-inner">
    <div class="testimonial-avatar">
<img decoding="async" src="https://www.crackersindia.com/wp-content/webp-express/webp-images/uploads/2019/01/31.jpg.webp" class="testimonial-avatar-image">			</div>

<div class="testimonial-content">
<div class="testimonial-rating">
<span class="star-rating">
    <span style="width:100%"></span>
</span>
</div>

<p>Service very excellent with in one week reach at home I m happy with that , quality was good . Every year I will buy crackers India only.</p>
<footer>
DIVYA
                    <span>
        Chennai					</span>
            </footer>
</div>
</div>
</div></div><div class="owl-item cloned" style="width: 954.8px;"><div class="testimonial column">
<div class="testimonial-inner">
    <div class="testimonial-avatar">
<img decoding="async" src="https://www.crackersindia.com/wp-content/webp-express/webp-images/uploads/2023/02/unnamed.png.webp" class="testimonial-avatar-image">			</div>

<div class="testimonial-content">
<div class="testimonial-rating">
<span class="star-rating">
    <span style="width:100%"></span>
</span>
</div>

<p>I have ordered Crackers for marriage function and received it on time. My family really enjoyed your varities. Thanks to Crackers India for valuable services.</p>
<footer>
JULIUS CEASER
                    <span>
        Nagerkovil					</span>
            </footer>
</div>
</div>
</div></div></div></div><div class="owl-nav disabled"><div class="owl-prev wd-btn-arrow"></div><div class="owl-next wd-btn-arrow"></div></div><div class="owl-dots"><div class="owl-dot"><span></span></div><div class="owl-dot active"><span></span></div><div class="owl-dot"><span></span></div><div class="owl-dot"><span></span></div><div class="owl-dot"><span></span></div><div class="owl-dot"><span></span></div></div></div>
</div>
</div>
</div>
    </div>
</div>
<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-6d5ba675" data-id="6d5ba675" data-element_type="column">
<div class="elementor-widget-wrap">
                    </div>
</div>
            </div>
</section>
            </div>
    </div><!-- .main-page-wrapper --> 
</div> <!-- end row -->
</div>
        </div> 
        
        </div>
        
        <?php
            include 'includes/footer.php';
        ?>
    </body>
</html>